<?php
namespace App\Parse_mods;

interface ModParse {
    public function parse($mod, $type);
}